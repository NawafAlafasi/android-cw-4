package com.example.cw_3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final EditText x = findViewById(R.id.editText1);
        final EditText y = findViewById(R.id.editText2);
        final TextView result = findViewById(R.id.textview);

        final TextView uno = findViewById(R.id.textview);
        final EditText deux = findViewById(R.id.editText1);
        final EditText tres = findViewById(R.id.editText2);

        Button add = findViewById(R.id.button);
        Button minus = findViewById(R.id.button1);
        Button multiply = findViewById(R.id.button2);
        Button divide = findViewById(R.id.button3);
        Button remainder = findViewById(R.id.button4);
        Button reset = findViewById(R.id.button5);

        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(x.getText().toString());
                int b = Integer.parseInt(y.getText().toString());
                int addd = a + b ;
                Toast.makeText(MainActivity.this, addd + "", Toast.LENGTH_SHORT).show();
                result.setText(addd + "");

            }
        });

        minus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(x.getText().toString());
                int b = Integer.parseInt(y.getText().toString());
                int answer = a - b ;
                result.setText(answer + "");
                Toast.makeText(MainActivity.this, answer + "", Toast.LENGTH_SHORT).show();
            }
        });

        multiply.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(x.getText().toString());
                int b = Integer.parseInt(y.getText().toString());
                int answer = a * b ;
                result.setText(answer + "");
                Toast.makeText(MainActivity.this, answer + "", Toast.LENGTH_SHORT).show();
            }
        });

        divide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(x.getText().toString());
                int b = Integer.parseInt(y.getText().toString());
                float answer = a / b ;
                result.setText(answer + "");
                Toast.makeText(MainActivity.this, answer + "", Toast.LENGTH_SHORT).show();
            }
        });

        remainder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int a = Integer.parseInt(x.getText().toString());
                int b = Integer.parseInt(y.getText().toString());
                float answer = a % b ;
                result.setText(answer + "");
                Toast.makeText(MainActivity.this, answer + "", Toast.LENGTH_SHORT).show();
            }
        });
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uno.setText("");
                deux.setText("");
                tres.setText("");
            }
        });
    }
}